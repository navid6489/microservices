-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 18, 2021 at 12:22 PM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 7.3.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `coremicroservice`
--

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(5, '2021_11_12_114527_create_notifications_table', 2),
(6, '2016_06_01_000001_create_oauth_auth_codes_table', 3),
(7, '2016_06_01_000002_create_oauth_access_tokens_table', 3),
(8, '2016_06_01_000003_create_oauth_refresh_tokens_table', 3),
(9, '2016_06_01_000004_create_oauth_clients_table', 3),
(10, '2016_06_01_000005_create_oauth_personal_access_clients_table', 3);

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `notifiable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `notifiable_id` bigint(20) UNSIGNED NOT NULL,
  `data` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `read_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `oauth_access_tokens`
--

CREATE TABLE `oauth_access_tokens` (
  `id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `client_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `scopes` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `revoked` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `expires_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `oauth_access_tokens`
--

INSERT INTO `oauth_access_tokens` (`id`, `user_id`, `client_id`, `name`, `scopes`, `revoked`, `created_at`, `updated_at`, `expires_at`) VALUES
('023cbf3346e912718dd294cea63e19a4d19c40ebf3ffe658e92ea5ba2421e989616a2cace1d5583f', 1, 5, 'MyApp', '[]', 0, '2021-11-16 08:06:33', '2021-11-16 08:06:33', '2022-11-16 13:36:33'),
('067d7f4d5f834db7d748ff756f4687b597553b344076fe0eb85fd401598bfe44dc6855b709bf9c08', 1, 5, 'MyApp', '[]', 0, '2021-11-18 01:57:04', '2021-11-18 01:57:04', '2022-11-18 07:27:04'),
('0a8dc9e7b55681f0f321eaa76a0444e6aa3cb1d44f448591bbbe82f594cf762d9d7896bb15f993e5', 1, 5, 'MyApp', '[]', 0, '2021-11-18 03:44:41', '2021-11-18 03:44:41', '2022-11-18 09:14:41'),
('0d203a065ee653ef673b2268a2b10d81630d51d8a92ee36ca38728fabe08a108649968a155984bd4', 1, 5, 'MyApp', '[]', 0, '2021-11-17 09:39:11', '2021-11-17 09:39:11', '2022-11-17 15:09:11'),
('1071a209f3cc666f65ba512d1150f1556605a25fd68063e448b908cd06392929659a5cb8d155c301', 1, 5, 'MyApp', '[]', 0, '2021-11-17 09:38:27', '2021-11-17 09:38:27', '2022-11-17 15:08:27'),
('10c7cf74b69777debb99aaf75d365c914fd0fdc0c1539a228da9a748f1a07e30db9b20e38ee025d5', 1, 5, 'MyApp', '[]', 0, '2021-11-18 03:48:53', '2021-11-18 03:48:53', '2022-11-18 09:18:53'),
('1792c8864b9c6b02d0384abf1c59c544510db247407c9a9c3d2b7252f44621a6a1643c636e89bb5d', 1, 5, 'MyApp', '[]', 0, '2021-11-17 08:18:54', '2021-11-17 08:18:54', '2022-11-17 13:48:54'),
('185ddd95461447f20eb8890be37598a6924a09d221034a2f88012a4f2ddaf6a8ea028d19c0551ed7', 1, 5, 'MyApp', '[]', 0, '2021-11-17 09:38:26', '2021-11-17 09:38:26', '2022-11-17 15:08:26'),
('2162f1c793d1254415d373a9811966bd762571612c6e2bcdcbfe6756031bda26bfd895d55fd27505', 1, 5, 'MyApp', '[]', 0, '2021-11-16 08:55:09', '2021-11-16 08:55:09', '2022-11-16 14:25:09'),
('2165a96a2ddf966978b6ac20ba92c6230b9fe04d12095c276b39e2373cbf9bb04406b79c90dd98d5', 1, 5, 'MyApp', '[]', 0, '2021-11-18 02:02:03', '2021-11-18 02:02:03', '2022-11-18 07:32:03'),
('22d7be7d2f6516e96e87ea775f5a447e9665a4b8344e477ab3fd3a4cfbb3b3571ec039c0dacd92e9', 1, 5, 'MyApp', '[]', 0, '2021-11-17 09:41:09', '2021-11-17 09:41:09', '2022-11-17 15:11:09'),
('23fbfdf2cf4a8899c8356dabe9bfddbdaacb6f4646e4af0311eff8b431adadc25189c21a8ec26af9', 1, 5, 'MyApp', '[]', 0, '2021-11-18 03:07:56', '2021-11-18 03:07:56', '2022-11-18 08:37:56'),
('24542c61407268ef62e5ee694a66e5db0028df7bcb3b51b0a103418c6ffe0393d12a9e2deeed6390', 1, 5, 'MyApp', '[]', 0, '2021-11-18 01:56:58', '2021-11-18 01:56:58', '2022-11-18 07:26:58'),
('26fcf4a2a4997cbbf18f103efa6c957dfca4c42c3de3f5ca237d1643eb4851c213c8bb4079a8b338', 1, 5, 'MyApp', '[]', 0, '2021-11-17 05:53:31', '2021-11-17 05:53:31', '2022-11-17 11:23:31'),
('27e31c1660e9dc50393dbaa98d4c06a637432eea86601d4bee8fc954c37b6f7d283a99ede816b389', 1, 5, 'MyApp', '[]', 0, '2021-11-16 05:49:54', '2021-11-16 05:49:54', '2022-11-16 11:19:54'),
('2cacfda0d470fb31a75a79882b04e578548a731bacbea501a9ceed005318ca36ef73e131ee7aa90c', 1, 5, 'MyApp', '[]', 0, '2021-11-17 08:24:11', '2021-11-17 08:24:11', '2022-11-17 13:54:11'),
('392670532e28df5ecb55497171c62f2d1f998caae495fc926e33269992589dfb7752c112e4447e15', 1, 5, 'MyApp', '[]', 0, '2021-11-18 01:16:39', '2021-11-18 01:16:39', '2022-11-18 06:46:39'),
('40f047f064a9c01182d6b127b2f93364f583ad8424fe8625745af4847380e27096f5781512f9aa26', 1, 5, 'MyApp', '[]', 0, '2021-11-17 09:35:54', '2021-11-17 09:35:54', '2022-11-17 15:05:54'),
('465f7ba6cd097d24071a004cb84a2f8e04a972872502da18be04b1cf941a709e97b77bd7458bf5f6', 1, 5, 'MyApp', '[]', 0, '2021-11-17 08:32:59', '2021-11-17 08:32:59', '2022-11-17 14:02:59'),
('47c1936b0318f7138c485266eb0ff1f16b2933224ec13d08fda8cb46485116f12135111185f53eda', 1, 5, 'MyApp', '[]', 0, '2021-11-16 07:27:18', '2021-11-16 07:27:18', '2022-11-16 12:57:18'),
('488bedb4a4cc6a52217284e28e2650f71ca9dc5b460f758c3c8e60433ab4ac13ed81247637302695', 1, 5, 'MyApp', '[]', 0, '2021-11-17 08:34:34', '2021-11-17 08:34:34', '2022-11-17 14:04:34'),
('4c24c4921922832e89bcf06ff38794a19cd1d5f59e1ab3ee831d3628fc109d98d9158c31316aef11', 1, 5, 'MyApp', '[]', 0, '2021-11-16 08:51:57', '2021-11-16 08:51:57', '2022-11-16 14:21:57'),
('4c3eabee0c0f4b9cf3a8708679038b41e598e1ad8d2f32328136ff58e41f8ad47fc51990397c90ab', 1, 5, 'MyApp', '[]', 0, '2021-11-17 08:29:36', '2021-11-17 08:29:36', '2022-11-17 13:59:36'),
('4d30cc1dafa35c9f760dcc798581518e983fb633a7586b54eed7422d3bfc2ee25beffbafd6bbe68a', 1, 5, 'MyApp', '[]', 0, '2021-11-17 09:36:37', '2021-11-17 09:36:37', '2022-11-17 15:06:37'),
('4df6af3fe67450ca40e0b3ce9d190fc9bd16c819d892e5f44a2f16ec20b13ec52f11660809560c63', 1, 5, 'MyApp', '[]', 0, '2021-11-17 08:33:54', '2021-11-17 08:33:54', '2022-11-17 14:03:54'),
('50548f38eb7abd1132df8f16ef07307bb3c7e2d96665d0581fd54c485f1d67f65d1533f0764f8bc5', 1, 5, 'MyApp', '[]', 0, '2021-11-18 01:32:13', '2021-11-18 01:32:13', '2022-11-18 07:02:13'),
('59467478dd6a5b707244dcef3fdbe395cba28015575899a1184f4232af334189c843c0465ff058d6', 1, 5, 'MyApp', '[]', 0, '2021-11-18 01:27:46', '2021-11-18 01:27:46', '2022-11-18 06:57:46'),
('5a8f16b90432a33a16bc1ce6d785b610b188f869f4f2c664802f69fd808492a2b26e8cd2a7bf2af4', 1, 5, 'MyApp', '[]', 0, '2021-11-17 06:39:28', '2021-11-17 06:39:28', '2022-11-17 12:09:28'),
('5d6c130f43af4abaf3f32476807b14cc7f761be49ff16b9b1f476a11ada5165f4c1dd924e8e0333d', 1, 5, 'MyApp', '[]', 0, '2021-11-16 06:16:05', '2021-11-16 06:16:05', '2022-11-16 11:46:05'),
('63c32030ec9ed3b2dc6a8f67299b7eb6f1ab3fb9ea36c38ab8771924f4062b12785e533293460283', 1, 5, 'MyApp', '[]', 0, '2021-11-17 07:52:54', '2021-11-17 07:52:54', '2022-11-17 13:22:54'),
('63ec4c9c93160ba7d0a8eaf4e293e727e59fe7c63159e24ea687a4275d64cd8116ed876617701be2', 1, 5, 'MyApp', '[]', 0, '2021-11-18 02:13:24', '2021-11-18 02:13:24', '2022-11-18 07:43:24'),
('68b6d1da177b704da96ab9a4d50c0bdb20f8d939655c71db8a8125fc770e9a5582db5d6bf1a46cd8', 1, 5, 'MyApp', '[]', 0, '2021-11-17 09:35:53', '2021-11-17 09:35:53', '2022-11-17 15:05:53'),
('6fa369b35b9a007d0d3123083af4974e24a8c00bee047a57b46e3bcc7ff44137792a8d3ab96b7a38', 1, 5, 'MyApp', '[]', 0, '2021-11-18 02:13:28', '2021-11-18 02:13:28', '2022-11-18 07:43:28'),
('7160b185f82aa6555f1fad93f9f7ad344de3bf5ca40f52bbbddd866dcd3a5fdc4c2ee5338fc3b8eb', 1, 5, 'MyApp', '[]', 0, '2021-11-17 05:41:56', '2021-11-17 05:41:56', '2022-11-17 11:11:56'),
('78269217644996dc9b7bac109f10aadb1de0ea1eb5620c91b26099971f541c59810535a3657e4c91', 1, 5, 'MyApp', '[]', 0, '2021-11-17 09:41:10', '2021-11-17 09:41:10', '2022-11-17 15:11:10'),
('7c8016af0854f47f1ba2642b1394a5527cc345ad7a0d79659ebd566f128e8b7ea94bc2fc47ba2547', 1, 5, 'MyApp', '[]', 0, '2021-11-17 08:32:31', '2021-11-17 08:32:31', '2022-11-17 14:02:31'),
('7d85e4443df84f8761fd0eade686a779b914b2142f4cbd36cea9c5bd2fd0bac0457d04d344ea7811', 1, 5, 'MyApp', '[]', 0, '2021-11-17 01:44:38', '2021-11-17 01:44:38', '2022-11-17 07:14:38'),
('7e8d5aea6b961e8e167dec5c914c2d57d7f8dfe4be9e1614f02d90508ed72aabb42d3922fb8f4d8f', 1, 5, 'MyApp', '[]', 0, '2021-11-17 00:55:50', '2021-11-17 00:55:50', '2022-11-17 06:25:50'),
('80d4c09926df75d7b823420d444f61e1fbd56b368f42f3dcbca5af21f11a4381f3b0687408ed5bc4', 1, 5, 'MyApp', '[]', 0, '2021-11-18 01:18:39', '2021-11-18 01:18:39', '2022-11-18 06:48:39'),
('815bc4628cffbed9e5b4689da49dacf5c4224079a14dc61f79c17b34e37b00c502c937918e4eb79c', 1, 5, 'MyApp', '[]', 0, '2021-11-17 06:33:35', '2021-11-17 06:33:35', '2022-11-17 12:03:35'),
('843d575c9bd821d28a3963afd8c8302e7d87343bee4d7fe14ff3245be12e8bb43641c9a89f2eb77e', 1, 5, 'MyApp', '[]', 0, '2021-11-17 08:20:32', '2021-11-17 08:20:32', '2022-11-17 13:50:32'),
('881e8374ed705b3f5277abc3a19dc3ddb087b533c0fef334f96f9e5578583598b6468fceb257b9d8', 1, 5, 'MyApp', '[]', 0, '2021-11-17 00:53:32', '2021-11-17 00:53:32', '2022-11-17 06:23:32'),
('882bb06a7a08853d3c8257a76c44a4727f556f9bc1b59eedb323af0e81c2c421980748581799018a', 1, 5, 'MyApp', '[]', 0, '2021-11-17 08:25:07', '2021-11-17 08:25:07', '2022-11-17 13:55:07'),
('8eaf5197f1244a7b0cec44f0a83b4d78abc8ac73cfa35e75b8a69e1e690213beb85eb7d706719b35', 1, 5, 'MyApp', '[]', 0, '2021-11-17 06:39:30', '2021-11-17 06:39:30', '2022-11-17 12:09:30'),
('904f522483be964b169201078d90e7d0419f765d558ccef53c54c909ae7886f82f9e39a96598ef17', 1, 5, 'MyApp', '[]', 0, '2021-11-17 06:39:26', '2021-11-17 06:39:26', '2022-11-17 12:09:26'),
('9c3133c38f78fc9f6f11619c7b8006f5cc5aeba6ca143ebedbc3c322e721face15236e20e7b68627', 1, 5, 'MyApp', '[]', 0, '2021-11-16 08:53:22', '2021-11-16 08:53:22', '2022-11-16 14:23:22'),
('a84e5cd3fad79b203bdbacba8336fb028ab5f8e3517a13986a2aa786c62aaff02908f0d12c548cf1', 1, 5, 'MyApp', '[]', 0, '2021-11-18 01:50:14', '2021-11-18 01:50:14', '2022-11-18 07:20:14'),
('ad2f6a7607c578239a2eeb4ab22c57ecd3e7a631fd8d00dcd221d8daa2c577883f5af17748a0710c', 1, 5, 'MyApp', '[]', 0, '2021-11-18 03:52:34', '2021-11-18 03:52:34', '2022-11-18 09:22:34'),
('aeeb9fba1e56482e21a589df21862cf75c87441ad3db25559759a093e202047b4bd8399c9af89421', 1, 5, 'MyApp', '[]', 0, '2021-11-18 01:32:08', '2021-11-18 01:32:08', '2022-11-18 07:02:08'),
('b2babd9895fcb1c0d7c7a915588f4adc575b114093649afe4f84fb4f44f2f74233cce72bdb36f983', 1, 5, 'MyApp', '[]', 0, '2021-11-18 02:55:25', '2021-11-18 02:55:25', '2022-11-18 08:25:25'),
('b7eea65b2b0b5c658a14a0fa2bcb96f1c14d41a3ae67dd4965f1f1cfe87e0313f6d7aeb98b0b28b5', 1, 5, 'MyApp', '[]', 0, '2021-11-17 07:20:33', '2021-11-17 07:20:33', '2022-11-17 12:50:33'),
('bc06b78d43666a41a3179bbc94e150409513bbe00b594f62d66c72b961372f1f790d951a3497e572', 1, 5, 'MyApp', '[]', 0, '2021-11-17 08:21:04', '2021-11-17 08:21:04', '2022-11-17 13:51:04'),
('bd90862d0a9b1fb9f5c7caf2213686d256bee44a7ada1af3a79c3743c78e5eeb4ea683afaf444f54', 1, 5, 'MyApp', '[]', 0, '2021-11-18 01:49:17', '2021-11-18 01:49:17', '2022-11-18 07:19:17'),
('bdadceaa498879841abd9c449ec61f5bd6a0a5657ef515c88c8bb310af09871830c649b5ee4baf96', 1, 5, 'MyApp', '[]', 0, '2021-11-17 09:36:38', '2021-11-17 09:36:38', '2022-11-17 15:06:38'),
('be42762b424249988e416dfc6fadd3a630321b051640dd748a75d21a2e96b6ab462e74b56984ac82', 1, 5, 'MyApp', '[]', 0, '2021-11-18 02:49:01', '2021-11-18 02:49:01', '2022-11-18 08:19:01'),
('c49c9712736c45b1e67c72bfc91b0aec8f593306c1539d838bfc099a9be2cc29b72f41d70f4779d0', 1, 5, 'MyApp', '[]', 0, '2021-11-17 08:27:33', '2021-11-17 08:27:33', '2022-11-17 13:57:33'),
('c4ec1e4a10ea0d5653be3d877dcfa3f3f71df4cf2013f5946223bf8611b2e62633f16c4160cfc4b0', 1, 5, 'MyApp', '[]', 0, '2021-11-17 08:28:10', '2021-11-17 08:28:10', '2022-11-17 13:58:10'),
('c4f9155f12e061f9f345e4b603f0ae746d143364d3814fef05a082eb73dd06e0b1ee1c6e68d4facc', 1, 5, 'MyApp', '[]', 0, '2021-11-18 01:49:21', '2021-11-18 01:49:21', '2022-11-18 07:19:21'),
('c641b9251d7faa1dedb2d30e6225018e51b1b7945d1cd287f9f08ccd43d7ce5dd0320b14017a88e6', 1, 5, 'MyApp', '[]', 0, '2021-11-16 07:23:35', '2021-11-16 07:23:35', '2022-11-16 12:53:35'),
('c932b60189d237cc8532a60c74b5fb126783b4772cb7f70c172a4b3e8fd70c736c6c5388e1463563', 1, 5, 'MyApp', '[]', 0, '2021-11-18 02:52:29', '2021-11-18 02:52:29', '2022-11-18 08:22:29'),
('ccae3fd4cbaffc3b26692b10f605f049fb427136cac774dbad1fe59d5c1716b19ef46487415cdf1e', 1, 5, 'MyApp', '[]', 0, '2021-11-17 05:55:02', '2021-11-17 05:55:02', '2022-11-17 11:25:02'),
('cdadf09072a4ef8a3502c7e8c3ad7e3b96785d1a4622027ebe9c680e862a3aafb7c8967d6c201c35', 1, 5, 'MyApp', '[]', 0, '2021-11-18 01:51:56', '2021-11-18 01:51:56', '2022-11-18 07:21:56'),
('d377a5c8a27e3183c996e0b6f8ac2a0fbc7d1204ba8cb621582ae5437c3921315cd84d9423e07170', 1, 5, 'MyApp', '[]', 0, '2021-11-16 08:54:01', '2021-11-16 08:54:01', '2022-11-16 14:24:01'),
('d5301704c6d6590127bddd2fbd1fbb086ba03018a03b9ca19c87d065504fd2f915e9b156564ddce9', 1, 5, 'MyApp', '[]', 0, '2021-11-17 05:52:20', '2021-11-17 05:52:20', '2022-11-17 11:22:20'),
('d6eed39e60b7d96101ebc192e1b81ee8d5d99667963e9312f71cc118105e760cd8d5fe1164446c29', 1, 5, 'MyApp', '[]', 0, '2021-11-16 07:54:09', '2021-11-16 07:54:09', '2022-11-16 13:24:09'),
('dc3164d4b3639d9e66a3e4a5e68371d60639186c65e96ed8949318b9dc0ad2b3a401ad2f05cf2471', 1, 5, 'MyApp', '[]', 0, '2021-11-17 08:18:52', '2021-11-17 08:18:52', '2022-11-17 13:48:52'),
('dc4c196db466ff470a211ff4daa40a625639b80b800161876d5df329d689bf6708a11fafb6c5cb53', 1, 5, 'MyApp', '[]', 0, '2021-11-18 01:49:04', '2021-11-18 01:49:04', '2022-11-18 07:19:04'),
('dc9b59c80cddef5014c945acca8945c9371d949f1561141cba31f05c67a0d0347ba76c24a18227c6', 1, 5, 'MyApp', '[]', 0, '2021-11-17 09:39:12', '2021-11-17 09:39:12', '2022-11-17 15:09:12'),
('e7f7412c0848820404ae5e60cf4b7f7a6fd59565e9d271294b0f152c2826df658e07b276bf614581', 1, 5, 'MyApp', '[]', 0, '2021-11-17 08:31:35', '2021-11-17 08:31:35', '2022-11-17 14:01:35'),
('e983e434c1ecfbabf1408ef92c18a35d179d45571fcbeed24d2ec6f749ad707305a3a7c2f50ca0f9', 1, 5, 'MyApp', '[]', 0, '2021-11-17 00:54:50', '2021-11-17 00:54:50', '2022-11-17 06:24:50'),
('eb3c5826257d1cd6d76cbca725e35396adf7b71c133ecf2a54174dde1f839da67b84d333fc760cc9', 1, 5, 'MyApp', '[]', 0, '2021-11-18 01:52:55', '2021-11-18 01:52:55', '2022-11-18 07:22:55'),
('ec03b5fc7fe5e0755df2e6ba864e2237231e6d9116b4ca58e1ca0fceb7562bbfacc08ca4b16b0cfe', 1, 5, 'MyApp', '[]', 0, '2021-11-17 08:08:48', '2021-11-17 08:08:48', '2022-11-17 13:38:48'),
('ed94b8ac2456e129321a74e7ff89633eef38f84db9639c3ed97dcb984f9e780ab200c618b63de35d', 1, 5, 'MyApp', '[]', 0, '2021-11-17 05:47:40', '2021-11-17 05:47:40', '2022-11-17 11:17:40'),
('ee0f9abb6b0aaaae9b97cc96ae089ca0a65360ad3f6a6845a81766331dc245791aa9ff75abf8c9f2', 1, 5, 'MyApp', '[]', 0, '2021-11-18 02:02:08', '2021-11-18 02:02:08', '2022-11-18 07:32:08'),
('f58c68ebeaf45066fd2f6b34c794fa4308cbbe27ad1728cf068bde633fe7da724b69f7a4d71868b3', 1, 5, 'MyApp', '[]', 0, '2021-11-18 03:47:53', '2021-11-18 03:47:53', '2022-11-18 09:17:53'),
('f8962ea559abb1f839995985c9883ada88ecf8067aa2a9f38099e2429e2585c5bac877beb955696f', 1, 5, 'MyApp', '[]', 0, '2021-11-17 05:53:58', '2021-11-17 05:53:58', '2022-11-17 11:23:58'),
('fba025bd7e491680d35eab94973d697bcc34a9d4da598c9fe112cf249eddaae7f81cfa07b2420582', 1, 5, 'MyApp', '[]', 0, '2021-11-16 07:22:41', '2021-11-16 07:22:41', '2022-11-16 12:52:41');

-- --------------------------------------------------------

--
-- Table structure for table `oauth_auth_codes`
--

CREATE TABLE `oauth_auth_codes` (
  `id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `client_id` bigint(20) UNSIGNED NOT NULL,
  `scopes` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `revoked` tinyint(1) NOT NULL,
  `expires_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `oauth_clients`
--

CREATE TABLE `oauth_clients` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `secret` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `provider` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `redirect` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `personal_access_client` tinyint(1) NOT NULL,
  `password_client` tinyint(1) NOT NULL,
  `revoked` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `oauth_clients`
--

INSERT INTO `oauth_clients` (`id`, `user_id`, `name`, `secret`, `provider`, `redirect`, `personal_access_client`, `password_client`, `revoked`, `created_at`, `updated_at`) VALUES
(1, NULL, 'Laravel Personal Access Client', 'Ua7kDxqEu3nx1KtLY25gi6u3Q5V4kBLE6L22yJ8Q', NULL, 'http://localhost', 1, 0, 0, '2021-11-12 07:58:46', '2021-11-12 07:58:46'),
(2, NULL, 'Laravel Password Grant Client', 'hASeKzUQd54nYHakifqcamGa0Ya8xEhTf8QSnj9U', 'users', 'http://localhost', 0, 1, 0, '2021-11-12 07:58:46', '2021-11-12 07:58:46'),
(3, 1, 'client1', 'AkKRHTyT2s6r6nVWXBfU5p8HfJTR0DmrMxuppc9y', NULL, 'www.google.com', 0, 0, 0, '2021-11-15 04:48:20', '2021-11-15 04:48:20'),
(4, NULL, 'client1', 'g8eURi8UwTOvtTqtoC45gPD0P1QX2iYZh3uC2Z8X', NULL, 'http://127.0.0.1:8000/', 0, 0, 0, '2021-11-15 05:57:25', '2021-11-15 05:57:25'),
(5, NULL, 'Laravel Personal Access Client', 'ntNiRqf7czsYoLEB9aogfbB5DsKoceHgEMhqZ39u', NULL, 'http://localhost', 1, 0, 0, '2021-11-16 01:10:47', '2021-11-16 01:10:47'),
(6, NULL, 'Laravel Password Grant Client', 'qFjknYlkXAcI3I9Vepa90oeQit9Y57m4uHYSzWLQ', 'users', 'http://localhost', 0, 1, 0, '2021-11-16 01:10:47', '2021-11-16 01:10:47');

-- --------------------------------------------------------

--
-- Table structure for table `oauth_personal_access_clients`
--

CREATE TABLE `oauth_personal_access_clients` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `client_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `oauth_personal_access_clients`
--

INSERT INTO `oauth_personal_access_clients` (`id`, `client_id`, `created_at`, `updated_at`) VALUES
(1, 1, '2021-11-12 07:58:46', '2021-11-12 07:58:46'),
(2, 5, '2021-11-16 01:10:47', '2021-11-16 01:10:47');

-- --------------------------------------------------------

--
-- Table structure for table `oauth_refresh_tokens`
--

CREATE TABLE `oauth_refresh_tokens` (
  `id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `access_token_id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `revoked` tinyint(1) NOT NULL,
  `expires_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `assignedteacher` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `flag` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `role`, `assignedteacher`, `flag`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'abc', 'abc@gmail.com', NULL, '$2y$10$4TKuUmwV30Ox81OYE/cFo.BIRzoIR4gEdpsQRSVJr5r1mrlXYj4re', 'admin', NULL, '0', NULL, '2021-11-08 03:48:39', '2021-11-08 03:48:39');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`id`),
  ADD KEY `notifications_notifiable_type_notifiable_id_index` (`notifiable_type`,`notifiable_id`);

--
-- Indexes for table `oauth_access_tokens`
--
ALTER TABLE `oauth_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD KEY `oauth_access_tokens_user_id_index` (`user_id`);

--
-- Indexes for table `oauth_auth_codes`
--
ALTER TABLE `oauth_auth_codes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `oauth_auth_codes_user_id_index` (`user_id`);

--
-- Indexes for table `oauth_clients`
--
ALTER TABLE `oauth_clients`
  ADD PRIMARY KEY (`id`),
  ADD KEY `oauth_clients_user_id_index` (`user_id`);

--
-- Indexes for table `oauth_personal_access_clients`
--
ALTER TABLE `oauth_personal_access_clients`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `oauth_refresh_tokens`
--
ALTER TABLE `oauth_refresh_tokens`
  ADD PRIMARY KEY (`id`),
  ADD KEY `oauth_refresh_tokens_access_token_id_index` (`access_token_id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `oauth_clients`
--
ALTER TABLE `oauth_clients`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `oauth_personal_access_clients`
--
ALTER TABLE `oauth_personal_access_clients`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
